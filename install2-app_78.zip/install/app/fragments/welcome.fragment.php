<div id="welcome" class="step">

    <h1 class="title"><?=INSTALL_PROJECT_NAME?> - Installation</h1>
    <p>

    </p>

</div>
