        <div id="success" class="step">
            <span class="icon mdi mdi-checkbox-marked-circle-outline color-green"></span>
            <h2 class="title">Success!</h2>
            <p>Application has been installed successfully!</p>
            
            <div class="sub">Don't forget to remove install directory!</div>

            <div class="go">

                <div id="userInfos" style="    padding: 30px;background: #eeeeee;margin-bottom: 13px;border: 1px solid #F44336;">
                </div>

                <a id="redirect" href="#" class="oval button">Login</a>
            </div>
        </div>